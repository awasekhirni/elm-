module Main exposing (..)

import Html exposing (text)
import List 

stockListing=
 let 
   mystocks=[ 26.55,36.45,86.55,48.55]
 in
  List.reverse mystocks
  |> Debug.toString 


main =
 text stockListing  
