module Main exposing (..)
-- Syed Awase Khirni SYCLIQ/TPRI www.sycliq.com www.territorialprescience.com 
import Html exposing (text)
-- this is a comment in elm 
main = 
 computeInterest 1000 3
 |> text
--function type signatures 
computeTax: Float -> Float -> String 
computeTax amount taxrate =
 Debug.toString (amount * taxrate / 100) 
 --function type signatures
computeInterest: Float -> Float -> String 
computeInterest amount interestrate = 
 amount * interestrate / 100 
 |> Debug.toString
 --function type signatures
computeRatio: Float -> Float -> String
computeRatio divisor dividend =
 dividend / divisor 
  |> Debug.toString 
-- function currying 
isdivisibleBy3: Float -> String
isdivisibleBy3 =
 computeRatio 3