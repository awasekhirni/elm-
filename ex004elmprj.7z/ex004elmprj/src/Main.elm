module Main exposing (..)

import Browser 
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)

--main 
main =
 Browser.sandbox { init = init, update = update, view = view}

--Model 
type alias Model =
 { name : String,
  password : String,
  passwordAgain : String 
 }

init : Model 
init = 
 Model "" "" ""

--update 
type Msg
 = Name String 
 | Password String 
 | PasswordAgain String 

--type signature 
update : Msg -> Model -> Model
update msg model =
 case msg of 
  Name name ->
   { model | name = name}
  Password password ->
   { model | password = password}
  PasswordAgain password ->
   { model | passwordAgain = password}


--view component 

view : Model -> Html Msg
view model =
 div []
  [ viewInput "text" "Name" model.name Name,
   viewInput "password" "Password" model.password Password,
   viewInput "password" "Re-enter Password" model.passwordAgain PasswordAgain,
   viewValidation model]

--function
viewInput :String -> String -> String -> (String -> msg) -> Html msg
viewInput inputtype placehold val toMsg =
 input [ type_ inputtype, placeholder placehold, value val, onInput toMsg ] []

--function 
viewValidation : Model -> Html msg 
viewValidation model = 
 if model.password == model.passwordAgain then 
  div [ style "color" "green" ] [text "OK"]
 else
  div [ style "color" "red" ] [text "Passwords do not match!"]