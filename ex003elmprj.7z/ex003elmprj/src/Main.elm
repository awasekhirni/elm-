module Main exposing (..)
-- importing the browser object
import Browser
-- html dependencies 
import Html exposing (Html, Attribute, div, input, text)
-- html attributes import 
import Html.Attributes exposing (..)
-- importing html events 
import Html.Events exposing (onInput)

-- beginprogram call for mvu
main = 
 Browser.sandbox { init = init, update = update, view = view}

--model context 
type alias Model =
 { content : String }

-- initializing the state of the application
init : Model 
init =  
 { content = ""}


--updating the state of the app 

type Msg
    = Change String 
    
--type signature declaration for update 
update : Msg -> Model -> Model 
update msg model = 
 case msg of 
  Change newContent ->
   { model | content = newContent}


--view context rendering 
-- type signature declarations 
view : Model -> Html Msg 
view model = 
 div []
  [ input [ placeholder "Text to reverse", value model.content, onInput Change ] []
  , div [] [ text (String.reverse model.content) ]
  ]